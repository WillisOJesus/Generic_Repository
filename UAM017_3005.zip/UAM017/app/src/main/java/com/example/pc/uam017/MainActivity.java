package com.example.pc.uam017;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


//


    GBD db = new GBD(this);


   // private List<Tarefa> tarefas = new ArrayList<Tarefa>();
    private ArrayAdapter<Tarefa> adaptador = null;


 /*   ListView lst_view;

    ArrayAdapter<String> adapter;      // para listar tarefas
    ArrayList<String> arrayList;  // para listar tarefas
*/


    /*
    ArrayAdapter<String> itemsAdapter =
            new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);
*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

                /* VERIFICAR ERRROOOO*//*
        ListView lista = (ListView) findViewById(R.id.lst_tarefas);
        adaptador = new ArrayAdapter<Tarefa>(this, android.R.layout.simple_list_item_1, db.listaTarefas());
        lista.setAdapter(adaptador);
*/



        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);





        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();

                Intent it = new Intent(MainActivity.this, TarefasActivity.class);
                startActivity(it);

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_todas_tarefas) {
            // Handle the camera action
        } else if (id == R.id.nav_concluidas) {

        } else if (id == R.id.nav_pendentes) {

        } else if (id == R.id.nav_export_web
                ) {

        /*} else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {
*/
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


//  mostrar tabela tela inicial
  public void listarTarefas() {

















      //List<Tarefa> tarefas = db.listaTarefas();
      //Toast.makeText(getApplicationContext(), tarefas.get(0).getNome() , Toast.LENGTH_SHORT).show();
//      arrayList = new ArrayList<String>();
//  adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, arrayList);
//  lst_view.setAdapter(adapter);

//      ListView listView = (ListView) findViewById(R.id.lst_tarefas);
//      listView.setAdapter(itemAdp);

      //for (Tarefa c : tarefas) {

     //     arrayList.add(c.getId() +"-" +c.getNome() + "-"+ c.getData());
        //adapter.notifyDataSetChanged();

          //Log.d("Lista","\nid " + c.getNome() +" | " + c.getId());
          //arrayList.add(c.getId() + "-" + c.getNome() + "-" + c.getData());
          //adapter.notifyDataSetChanged();


     //}



/*
      arrayList = new ArrayList<String>();
      adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, arrayList);
      Toast.makeText(getApplicationContext(), "AQUI", Toast.LENGTH_SHORT).show();

      listatodasTarefas.setAdapter(adapter);


          Toast.makeText(getApplicationContext(), c.getNome(), Toast.LENGTH_SHORT).show();

      }

*/
  }

}
