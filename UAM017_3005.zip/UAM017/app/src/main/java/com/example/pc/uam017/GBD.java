package com.example.pc.uam017;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.R.attr.id;

/**
 * Created by willi on 29/05/2017.
 */

public class GBD extends SQLiteOpenHelper {





    private static final int VERSAO_BANCO=6;
    private static final String BANCO_NOME="BD_TAREFAS";

    public static final String NOME_TABELA   		= "TB_TAREFAS";
    public static final String COLUNA_ID         	= "id";
    public static final String COLUNA_NOME 			= "nome";
    public static final String COLUNA_TIPO 			= "tipo";
    public static final String COLUNA_CONTATO 		= "contato";
    public static final String COLUNA_MENSAGEM 		= "mensagem";
    public static final String COLUNA_DATA 			= "data";
    public static final String COLUNA_IMPORTANCIA	= "importancia";



    public GBD(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    public GBD(Context context) {
        super(context, BANCO_NOME, null, VERSAO_BANCO);
    }

    public GBD(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
String QUERY_CRIACAO = "CREATE TABLE " + NOME_TABELA + " ("
        + COLUNA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
        + COLUNA_NOME 	  + " TEXT ,"
        + COLUNA_TIPO 	  + " INTEGER ,"
        + COLUNA_CONTATO  + " TEXT ,"
        + COLUNA_MENSAGEM + " TEXT ,"
        + COLUNA_DATA + " TEXT ,"
        + COLUNA_IMPORTANCIA     + " TEXT )";

        db.execSQL(QUERY_CRIACAO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + NOME_TABELA);
        onCreate(db);
    }



    void addTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
        ContentValues values  = new ContentValues();

        //values.put(COLUNA_ID      ,tarefa.getId());
        values.put(COLUNA_NOME    ,tarefa.getNome());
        values.put(COLUNA_TIPO    ,tarefa.getTipo());
        values.put(COLUNA_CONTATO ,tarefa.getContato());
        values.put(COLUNA_MENSAGEM,tarefa.getMensagem());
        values.put(COLUNA_DATA    ,tarefa.getData());
        values.put(COLUNA_IMPORTANCIA    ,tarefa.getImportancia());
        db.insert(NOME_TABELA,null,values);
        db.close();
    }



    void apagarTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
      db.delete(NOME_TABELA,COLUNA_ID + " = ?", new String[] {String.valueOf(tarefa.getId())});
        db.close();;
    }


    Tarefa selecionarTarefa(int tarefa){

        SQLiteDatabase db =  this.getReadableDatabase();
        Cursor cursor = db.query(NOME_TABELA,
                new String[]{COLUNA_ID, COLUNA_NOME, COLUNA_TIPO, COLUNA_CONTATO, COLUNA_MENSAGEM, COLUNA_DATA,COLUNA_IMPORTANCIA},
                COLUNA_ID + " = ?",
                new String[]{String.valueOf(tarefa)},null,null,null,null);
if(cursor!=null){
cursor.moveToFirst();
}

Tarefa tarefa_retorno = new Tarefa(Integer.parseInt(
        cursor.getString(0)),
        cursor.getString(1),
        Integer.parseInt(cursor.getString(2)),
        cursor.getString(3),
        cursor.getString(4),
        cursor.getString(5),
        cursor.getString(6)
        );


        return tarefa_retorno;
    }


    void atualizaTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
        ContentValues values  = new ContentValues();
//3 teste
//4 2
//5 email
        values.put(COLUNA_ID      ,tarefa.getId());
        values.put(COLUNA_NOME    ,tarefa.getNome());
        values.put(COLUNA_TIPO    ,tarefa.getTipo());
        values.put(COLUNA_CONTATO ,tarefa.getContato());
        values.put(COLUNA_MENSAGEM,tarefa.getMensagem());
        values.put(COLUNA_DATA    ,tarefa.getData());
        values.put(COLUNA_IMPORTANCIA    ,tarefa.getImportancia());


        db.update(NOME_TABELA,values,COLUNA_ID + " = ?", new String[] {String.valueOf(tarefa.getId())});

        db.close();
    }


    public List<Tarefa> listaTarefas(){

        List<Tarefa> listaTarefas = new ArrayList<Tarefa>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + NOME_TABELA;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {

                Tarefa tarefa= new Tarefa();


                tarefa.setId(Integer.parseInt(cursor.getString(0)));
                tarefa.setNome(cursor.getString(1));
                tarefa.setTipo(Integer.parseInt(cursor.getString(2)));
                tarefa.setContato(cursor.getString(3));
                tarefa.setMensagem(cursor.getString(4));
                tarefa.setData(cursor.getString(5));
                tarefa.setImportancia(cursor.getString(6));


                listaTarefas.add(tarefa);
                //Toast.makeText(getApplicationContext(), tarefa.getNome() , Toast.LENGTH_SHORT).show();

/*                Tarefa tarefa = new Tarefa(
                        Integer.parseInt(
                                cursor.getString(0)),
                        cursor.getString(1),
                        Integer.parseInt(cursor.getString(2)),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6));
                // Adding contact to list
                listaTarefas.add(tarefa);


  */          } while (cursor.moveToNext());
        }

        // return contact list
        return listaTarefas;









  /*      List<Tarefa> listaTarefas =  new ArrayList<Tarefa>();
        String query = " SELECT * FROM " + NOME_TABELA;

        SQLiteDatabase db =  this.getWritableDatabase();
        Cursor c = db.rawQuery(query,null);

        if(c.moveToFirst()){
do{

Tarefa tarefa = new Tarefa(
        Integer.parseInt(
                c.getString(0)),
        c.getString(1),
        Integer.parseInt(c.getString(2)),
        c.getString(3),
        c.getString(4),
        c.getString(5),
        c.getString(6));

    listaTarefas.add(tarefa);

}while(c.moveToNext());


        }

        return listaTarefas;
*/
    }






}
