package com.example.pc.uam017;

import java.util.Date;

/**
 * Created by willi on 28/05/2017.
 */

public class Tarefa {
    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    private int Id;
    private String nome;
    private int tipo;
    private String contato;
    private String mensagem;
    private String data;
    private String importancia;
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Tarefa(int id, String nome, int tipo, String contato, String mensagem, String data, String importancia, int status) {
        Id = id;
        this.nome = nome;
        this.tipo = tipo;
        this.contato = contato;
        this.mensagem = mensagem;
        this.data = data;
        this.importancia = importancia;
        this.status = status;
    }

    public Tarefa(){
    }

    public Tarefa(String nome, int tipo, String contato, String mensagem, String data, String importancia) {
        this.nome = nome;
        this.tipo = tipo;
        this.contato = contato;
        this.mensagem = mensagem;
        this.data = data;
        this.importancia = importancia;
    }


    public String getNome() {
        return nome;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getImportancia() {
        return importancia;
    }

    public void setImportancia(String importancia) {
        this.importancia = importancia;
    }


}
