package com.example.pc.uam017;

import java.util.Date;

/**
 * Created by willi on 28/05/2017.
 */

public class Tarefa {
    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    private int Id;
    private String nome;
    private int tipo;
    private String contato;
    private String mensagem;
    private String data;

    public Tarefa(int id, String nome, int tipo, String contato, String mensagem, String data) {
        Id = id;
        this.nome = nome;
        this.tipo = tipo;
        this.contato = contato;
        this.mensagem = mensagem;
        this.data = data;
    }

    public Tarefa(){

    }

    public Tarefa(String nome, int tipo, String contato, String mensagem, String data) {
        this.nome = nome;
        this.tipo = tipo;
        this.contato = contato;
        this.mensagem = mensagem;
        this.data = data;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }


}
