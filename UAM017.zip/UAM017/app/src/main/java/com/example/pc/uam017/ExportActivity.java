package com.example.pc.uam017;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ExportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export);

        Button bt_export =(Button) findViewById(R.id.btn_export);;
        final TextView txtCpf = (TextView) findViewById(R.id.txt_cpf );


        bt_export.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtCpf.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(), "Campo CPF não pode ser nulo", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Enviar para WEB Service para validação \n " +
                            "Exporta Informações para MySQL On Line", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}
