package com.example.pc.uam017;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by willi on 29/05/2017.
 */

public class GBD extends SQLiteOpenHelper {

    private static final int VERSAO_BANCO=1;
    private static final String BANCO_NOME="BD_TAREFAS";

    public static final String NOME_TABELA   		= "TB_TAREFAS";
    public static final String COLUNA_ID         	= "id";
    public static final String COLUNA_NOME 			= "nome";
    public static final String COLUNA_TIPO 			= "tipo";
    public static final String COLUNA_CONTATO 		= "contato";
    public static final String COLUNA_MENSAGEM 		= "mensagem";
    public static final String COLUNA_DATA 			= "data";

    public GBD(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    public GBD(Context context) {
        super(context, BANCO_NOME, null, VERSAO_BANCO);
    }

    public GBD(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
String QUERY_CRIACAO = "CREATE TABLE " + NOME_TABELA + " ("
        + COLUNA_ID + "INTEGER PRIMARY KEY , "
        + NOME_TABELA     + " TEXT ,"
        + COLUNA_ID       + " INTEGER ,"
        + COLUNA_NOME 	  + " TEXT ,"
        + COLUNA_TIPO 	  + " INTEGER ,"
        + COLUNA_CONTATO  + " TEXT ,"
        + COLUNA_MENSAGEM + " TEXT ,"
        + COLUNA_DATA     + " TEXT )";

        db.execSQL(QUERY_CRIACAO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }



    void addTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
        ContentValues values  = new ContentValues();

        values.put(COLUNA_ID      ,tarefa.getId());
        values.put(COLUNA_NOME    ,tarefa.getNome());
        values.put(COLUNA_TIPO    ,tarefa.getTipo());
        values.put(COLUNA_CONTATO ,tarefa.getContato());
        values.put(COLUNA_MENSAGEM,tarefa.getMensagem());
        values.put(COLUNA_DATA    ,tarefa.getData());

        db.insert(NOME_TABELA,null,values);
        db.close();
    }



    void apagarTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
      db.delete(NOME_TABELA,COLUNA_ID + " = ?", new String[] {String.valueOf(tarefa.getId())});
        db.close();;
    }


    Tarefa selecionarTarefa(int tarefa){

        SQLiteDatabase db =  this.getReadableDatabase();
        Cursor cursor = db.query(NOME_TABELA,
                new String[]{COLUNA_ID, COLUNA_NOME, COLUNA_TIPO, COLUNA_CONTATO, COLUNA_MENSAGEM, COLUNA_DATA},
                COLUNA_ID + " = ?",
                new String[]{String.valueOf(tarefa)},null,null,null,null);
if(cursor!=null){
cursor.moveToFirst();
}

Tarefa tarefa_retorno = new Tarefa(Integer.parseInt(
        cursor.getString(0)),
        cursor.getString(1),
        Integer.parseInt(cursor.getString(2)),
        cursor.getString(3),
        cursor.getString(4),
        cursor.getString(5)
        );


        return tarefa_retorno;
    }


    void atualizaTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
        ContentValues values  = new ContentValues();

        values.put(COLUNA_ID      ,tarefa.getId());
        values.put(COLUNA_NOME    ,tarefa.getNome());
        values.put(COLUNA_TIPO    ,tarefa.getTipo());
        values.put(COLUNA_CONTATO ,tarefa.getContato());
        values.put(COLUNA_MENSAGEM,tarefa.getMensagem());
        values.put(COLUNA_DATA    ,tarefa.getData());


        db.update(NOME_TABELA,values,COLUNA_ID + " = ?", new String[] {String.valueOf(tarefa.getId())});

        db.close();
    }


    public List<Tarefa> listaTarefas(){

        List<Tarefa> listaTarefas =  new ArrayList<Tarefa>();
        String query = " SELECT * FROM " + NOME_TABELA;

        SQLiteDatabase db =  this.getReadableDatabase();
        Cursor c = db.rawQuery(query,null);

        if(c.moveToFirst()){
do{

Tarefa tarefa = new Tarefa(
        Integer.parseInt(
                c.getString(0)),
        c.getString(1),
        Integer.parseInt(c.getString(2)),
        c.getString(3),
        c.getString(4),
        c.getString(5));

    listaTarefas.add(tarefa);

}while(c.moveToNext());


        }

        return listaTarefas;

    }






}
