package com.example.pc.uam017;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.R.attr.content;
import static android.R.attr.id;

/**
 * Created by willi on 29/05/2017.
 */

public class GBD extends SQLiteOpenHelper {


    private static final int VERSAO_BANCO=7;
    private static final String BANCO_NOME="BD_TAREFAS";

    public static final String NOME_TABELA   		= "TB_TAREFAS";
    public static final String COLUNA_ID         	= "id";
    public static final String COLUNA_NOME 			= "nome";
    public static final String COLUNA_TIPO 			= "tipo";
    public static final String COLUNA_CONTATO 		= "contato";
    public static final String COLUNA_MENSAGEM 		= "mensagem";
    public static final String COLUNA_DATA 			= "data";
    public static final String COLUNA_IMPORTANCIA	= "importancia";
    public static final String COLUNA_STATUS	= "status";



    public  GBD(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    public GBD(Context context) {
        super(context , BANCO_NOME, null, VERSAO_BANCO);
    }

    public GBD(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
String QUERY_CRIACAO = "CREATE TABLE " + NOME_TABELA + " ("
        + COLUNA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
        + COLUNA_NOME 	  + " TEXT ,"
        + COLUNA_TIPO 	  + " INTEGER ,"
        + COLUNA_CONTATO  + " TEXT ,"
        + COLUNA_MENSAGEM + " TEXT ,"
        + COLUNA_DATA + " TEXT ,"
        + COLUNA_IMPORTANCIA + " TEXT ,"
        + COLUNA_STATUS     + " INTEGER )";

        db.execSQL(QUERY_CRIACAO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + NOME_TABELA);
        onCreate(db);
    }



    void addTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
        ContentValues values  = new ContentValues();

        //values.put(COLUNA_ID      ,tarefa.getId());
        values.put(COLUNA_NOME    ,tarefa.getNome());
        values.put(COLUNA_TIPO    ,tarefa.getTipo());
        values.put(COLUNA_CONTATO ,tarefa.getContato());
        values.put(COLUNA_MENSAGEM,tarefa.getMensagem());
        values.put(COLUNA_DATA    ,tarefa.getData());
        values.put(COLUNA_IMPORTANCIA    ,tarefa.getImportancia());
        values.put(COLUNA_STATUS    ,0);
        db.insert(NOME_TABELA,null,values);
        db.close();
    }


void DMLCommit(String query){
    SQLiteDatabase db =  this.getWritableDatabase();
    db.execSQL(query);

}


    void apagarTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();

      db.delete(NOME_TABELA,COLUNA_ID + " = ?", new String[] {String.valueOf(tarefa.getId())});
        db.close();;
    }


    Tarefa selecionarTarefa(int tarefa){

        SQLiteDatabase db =  this.getReadableDatabase();
        Cursor cursor = db.query(NOME_TABELA,
                new String[]{COLUNA_ID, COLUNA_NOME, COLUNA_TIPO, COLUNA_CONTATO, COLUNA_MENSAGEM, COLUNA_DATA,COLUNA_IMPORTANCIA,COLUNA_STATUS},
                COLUNA_ID + " = ?",
                new String[]{String.valueOf(tarefa)},null,null,null,null);
if(cursor!=null){
cursor.moveToFirst();
}

Tarefa tarefa_retorno = new Tarefa(Integer.parseInt(
        cursor.getString(0)),
        cursor.getString(1),
        Integer.parseInt(cursor.getString(2)),
        cursor.getString(3),
        cursor.getString(4),
        cursor.getString(5),
        cursor.getString(6),
        Integer.parseInt(cursor.getString(7))
        );


        return tarefa_retorno;
    }


    void atualizaTarefa(Tarefa tarefa){

        SQLiteDatabase db =  this.getWritableDatabase();
        ContentValues values  = new ContentValues();
        values.put(COLUNA_ID      ,tarefa.getId());
        values.put(COLUNA_NOME    ,tarefa.getNome());
        values.put(COLUNA_TIPO    ,tarefa.getTipo());
        values.put(COLUNA_CONTATO ,tarefa.getContato());
        values.put(COLUNA_MENSAGEM,tarefa.getMensagem());
        values.put(COLUNA_DATA    ,tarefa.getData());
        values.put(COLUNA_IMPORTANCIA    ,tarefa.getImportancia());
        values.put(COLUNA_STATUS    ,tarefa.getStatus());

        db.update(NOME_TABELA,values,COLUNA_ID + "= ?", new String[] {String.valueOf(tarefa.getId())});

        db.close();
    }


    public List<Tarefa> listaTarefas( int status){
// 0 - Pendentes, 1-Concluida, 2 Todas
        List<Tarefa> listaTarefas = new ArrayList<Tarefa>();

        String selectQuery = "SELECT  * FROM " + NOME_TABELA;

        if(status==0 || status==1){
            selectQuery +=" WHERE " + COLUNA_STATUS + " = " + status;
        }


        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {

                Tarefa tarefa= new Tarefa();


                tarefa.setId(Integer.parseInt(cursor.getString(0)));
                tarefa.setNome(cursor.getString(1));
                tarefa.setTipo(Integer.parseInt(cursor.getString(2)));
                tarefa.setContato(cursor.getString(3));
                tarefa.setMensagem(cursor.getString(4));
                tarefa.setData(cursor.getString(5));
                tarefa.setImportancia(cursor.getString(6));
                tarefa.setStatus(Integer.parseInt(cursor.getString(7)));
                listaTarefas.add(tarefa);

   } while (cursor.moveToNext());
        }


        return listaTarefas;


    }





}
