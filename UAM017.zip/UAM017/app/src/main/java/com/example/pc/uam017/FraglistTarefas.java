package com.example.pc.uam017;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FraglistTarefas extends Fragment implements View.OnClickListener {

    Context context;
    ListView lista;
    Button bt_concluir;
    Button bt_excluir;
    TextView lbl_id;

    ;



    public FraglistTarefas() {
        // Required empty public constructor
    }

    //GBD db = new GBD( this.getContext());
    /**************************************************************************************************/
      ListView lst_view;

    ArrayAdapter<String> adapter;      // para listar tarefas
    ArrayList<String> arrayList;  // para listar tarefas
    /**************************************************************************************************/



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        context = inflater.getContext();

        View v = inflater.inflate(R.layout.fragment_fraglist_tarefas,container,false );

        bt_concluir = (Button) v.findViewById(R.id.btn_concluir);
        bt_excluir= (Button) v.findViewById(R.id.btn_excluir);
        lbl_id = (TextView) v.findViewById(R.id.lbl_id);
        lista = (ListView) v.findViewById(R.id.lst_tarefas);


        bt_excluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(lbl_id.getText().toString().equalsIgnoreCase("-")){
                    Toast.makeText(getActivity().getApplicationContext(),
                            "Selecione um item na Lista", Toast.LENGTH_SHORT ).show();
                }else{
                    GBD db = new GBD(context);
                    Tarefa tarefa = db.selecionarTarefa(Integer.parseInt(lbl_id.getText().toString()));
                        db.apagarTarefa(tarefa);
                }

            }
        });


        bt_concluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(lbl_id.getText().toString().equalsIgnoreCase("-")){
                    Toast.makeText(getActivity().getApplicationContext(),
                            "Selecione um item na Lista", Toast.LENGTH_SHORT ).show();
                }else{
                    GBD db = new GBD(context);
                    Tarefa tarefa = db.selecionarTarefa(Integer.parseInt(lbl_id.getText().toString()));
                    tarefa.setStatus(1);
                   db.atualizaTarefa(tarefa);

                  /*  db.DMLCommit("UPDATE " + GBD.NOME_TABELA + " SET " + GBD.COLUNA_STATUS +"=1 WHERE "
                    + GBD.COLUNA_ID + "=" + lbl_id.getText() );
*/
                    listarTarefas();




                }

            }
        });

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapter, View view,
                                    int posicao, long id) {
                //Toast.makeText(getActivity().getApplicationContext(),adapter.getItemAtPosition(posicao).toString(), Toast.LENGTH_SHORT ).show();
                String spltRxtraiID=adapter.getItemAtPosition(posicao).toString().split("|")[1].replace(" ","");

                lbl_id.setText(spltRxtraiID);
            }
        });





                listarTarefas();

        return v;

                // inflater.inflate(R.layout.fragment_fraglist_tarefas, container, false);







    }

    @Override
    public void onClick(View v) {
    }


    public void listarTarefas() {

        GBD db = new GBD(context);

      List<Tarefa> tarefas = db.listaTarefas(2);// 0 - Pendentes, 1-Concluida, 2 Todas
      arrayList = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(this.getContext() , android.R.layout.simple_list_item_1, arrayList);
      lista.setAdapter(adapter);

      for (Tarefa c : tarefas) {

         arrayList.add(c.getId() +" | " +c.getNome() + " | "+ c.getData() + "| Status: " + c.getStatus());
        adapter.notifyDataSetChanged();


     }



    }

}
