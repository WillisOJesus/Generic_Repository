package com.example.pc.uam017;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FraglistConcluidas extends Fragment implements View.OnClickListener {

    Context context;
    ListView lista;




    public FraglistConcluidas() {
        // Required empty public constructor
    }

    //GBD db = new GBD( this.getContext());
    /**************************************************************************************************/
      ListView lst_view;

    ArrayAdapter<String> adapter;      // para listar tarefas
    ArrayList<String> arrayList;  // para listar tarefas
    /**************************************************************************************************/



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        context = inflater.getContext();

        View v = inflater.inflate(R.layout.fragment_fraglist_tarefas,container,false );
      lista = (ListView) v.findViewById(R.id.lst_tarefas);

        listarTarefas();
        return v;// inflater.inflate(R.layout.fragment_fraglist_tarefas, container, false);
    }

    @Override
    public void onClick(View v) {
    }


    public void listarTarefas() {

        GBD db = new GBD(context);

      List<Tarefa> tarefas = db.listaTarefas(1);// 0 - Pendentes, 1-Concluida, 2 Todas
      arrayList = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(this.getContext() , android.R.layout.simple_list_item_1, arrayList);
      lista.setAdapter(adapter);

      for (Tarefa c : tarefas) {

          arrayList.add(c.getId() +" | " +c.getNome() + " | "+ c.getData() + "| Status: " + c.getStatus());
        adapter.notifyDataSetChanged();


     }



    }

}
