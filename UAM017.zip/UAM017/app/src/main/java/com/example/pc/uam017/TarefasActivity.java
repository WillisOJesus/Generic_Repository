package com.example.pc.uam017;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotSame;
import static junit.framework.Assert.assertSame;
import static junit.framework.Assert.assertTrue;

public class TarefasActivity extends AppCompatActivity {


    GBD db = new GBD(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefas);

        // DECLARAÇÃO DE OBEJTOS PARA MANIPULAÇÃO
        final Spinner spinner = (Spinner) findViewById(R.id.cbox_tipo);

        final EditText txtContato = (EditText)findViewById(R.id.txt_contato);
        final EditText txtTarefa = (EditText)findViewById(R.id.txt_tarefa);
        final EditText txtMensagem = (EditText)findViewById(R.id.txt_mensagem);
        final EditText txtData = (EditText)findViewById(R.id.txt_data);
        final EditText txtHora = (EditText)findViewById(R.id.txt_hora);

        final TextView label_contato = (TextView) findViewById(R.id.lbl_contato);


        final Button bt_limpar = (Button) findViewById(R.id.btn_limpar);
        Button bt_cancelar = (Button) findViewById(R.id.btn_cancelar);
        Button bt_salvar = (Button) findViewById(R.id.btn_salva);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planets_array, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);



        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String tipoMsg = spinner.getSelectedItem().toString();

//                Toast.makeText(getApplicationContext(), tipoMsg, Toast.LENGTH_SHORT).show();

                habilitaDesabilitaEditText((EditText)findViewById(R.id.txt_contato),!tipoMsg.equalsIgnoreCase("Lembrete"));





if (tipoMsg.equalsIgnoreCase("SMS")){
    //EditText txt = (EditText)findViewById(R.id.txt_contato);
    txtContato.setInputType(InputType.TYPE_CLASS_PHONE );
    label_contato.setText("Nunero do Celular");
}else if(tipoMsg.equalsIgnoreCase("Email")){
    txtContato.setInputType(InputType.TYPE_CLASS_TEXT);
    label_contato.setText("Endereço de Email");
}else{
    label_contato.setText("");
}

            }

            public void onNothingSelected(AdapterView<?> adapterView) {
                return;
            }


            private void habilitaDesabilitaEditText(EditText editText, boolean flag) {
                  editText.setEnabled(flag);
                if (flag){
                editText.setBackgroundColor(Color.WHITE);
                }else{
                    editText.setBackgroundColor(Color.TRANSPARENT);
                }
            }
        });



        bt_limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtContato.setText("");
                txtTarefa.setText("");
                txtMensagem.setText("");
                txtData.setText("");
                txtHora.setText("");

//                Toast.makeText(getApplicationContext(), "Limpar", Toast.LENGTH_SHORT).show();

            }
        });


        bt_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  finish();
                /*  TESTE DE CONSULTA */ /*
                Tarefa tarefa = db.selecionarTarefa(Integer.parseInt(txtTarefa.getText().toString()));
                Toast.makeText(getApplicationContext(), tarefa.getMensagem(), Toast.LENGTH_SHORT).show();
                */

                /* TESTE DE UPDATE*/
                Tarefa tarefa = new Tarefa(1, "nome", 1, "contato", "UPDATE", "02/06/2017 08:00");
                db.atualizaTarefa(tarefa);
                Toast.makeText(getApplicationContext(), "Atualizado com sucesso", Toast.LENGTH_SHORT).show();

            }
        });



        bt_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                db.addTarefa(new Tarefa(txtTarefa.getText().toString(), spinner.getSelectedItemPosition(),
                        txtContato.getText().toString(), txtMensagem.getText().toString(),
                        (String) (txtData.getText().toString())+ " " + txtHora.getText().toString()));

                Toast.makeText(getApplicationContext(), "Salvo com Sucesso", Toast.LENGTH_SHORT).show();
                bt_limpar.callOnClick();



            }
        });

    }







}
