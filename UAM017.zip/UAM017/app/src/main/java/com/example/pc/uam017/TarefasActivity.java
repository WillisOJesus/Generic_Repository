package com.example.pc.uam017;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class TarefasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefas);

        final Spinner spinner = (Spinner) findViewById(R.id.cbox_tipo);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planets_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);


        /*final Spinner  spcliente = (Spinner) findViewById(R.id.cbox_tipo);
        spcliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String tipoMsg = spcliente.getSelectedItem().toString();

                Toast.makeText(getApplicationContext(), tipoMsg, Toast.LENGTH_SHORT).show();
            }
          */


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String tipoMsg = spinner.getSelectedItem().toString();

//                Toast.makeText(getApplicationContext(), tipoMsg, Toast.LENGTH_SHORT).show();

                habilitaDesabilitaEditText((EditText)findViewById(R.id.txt_contato),!tipoMsg.equalsIgnoreCase("Lembrete"));

                EditText txt = (EditText)findViewById(R.id.txt_contato);
                TextView label_contato = (TextView) findViewById(R.id.lbl_contato);


if (tipoMsg.equalsIgnoreCase("SMS")){
    //EditText txt = (EditText)findViewById(R.id.txt_contato);
    txt.setInputType(InputType.TYPE_CLASS_PHONE );
    label_contato.setText("Nunero do Celular");
}else if(tipoMsg.equalsIgnoreCase("Email")){
    txt.setInputType(InputType.TYPE_CLASS_TEXT);
    label_contato.setText("Endereço de Email");
}else{
    label_contato.setText("");

}

            }

            public void onNothingSelected(AdapterView<?> adapterView) {
                return;
            }


            private void habilitaDesabilitaEditText(EditText editText, boolean flag) {
                  editText.setEnabled(flag);



                if (flag){
                editText.setBackgroundColor(Color.WHITE);
                }else{
                    editText.setBackgroundColor(Color.TRANSPARENT);
                }

            }


        });


        Button bt_limpar = (Button) findViewById(R.id.btn_limpar);
        bt_limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText tst = (EditText)findViewById(R.id.txt_contato);
                tst.setContentDescription(" ");

            }
        });



    }




}
