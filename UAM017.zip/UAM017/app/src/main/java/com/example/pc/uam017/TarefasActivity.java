package com.example.pc.uam017;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotSame;
import static junit.framework.Assert.assertSame;
import static junit.framework.Assert.assertTrue;

public class TarefasActivity extends AppCompatActivity {

    private static final int SEL_CONT = 1;
    private EditText txtContato;
    private EditText txtTarefa;
    private EditText txtMensagem;
    private EditText txtData;
    private EditText txtHora;
    private Spinner spi_tipo;
    private Spinner spi_importancia;
   public GBD db = new GBD(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefas);

        // DECLARAÇÃO DE OBEJTOS PARA MANIPULAÇÃO
        spi_tipo = (Spinner) findViewById(R.id.cbox_tipo);
        spi_importancia = (Spinner) findViewById(R.id.cbox_importancia);

        txtContato = (EditText)findViewById(R.id.txt_contato);
        txtTarefa = (EditText)findViewById(R.id.txt_tarefa);
        txtMensagem = (EditText)findViewById(R.id.txt_mensagem);
        txtData = (EditText)findViewById(R.id.txt_data);
        txtHora = (EditText)findViewById(R.id.txt_hora);

        final TextView label_contato = (TextView) findViewById(R.id.lbl_contato);


        final Button bt_limpar = (Button) findViewById(R.id.btn_limpar);
        Button bt_cancelar = (Button) findViewById(R.id.btn_cancelar);
        Button bt_salvar = (Button) findViewById(R.id.btn_salva);
        final ImageButton bt_contato =(ImageButton) findViewById(R.id.button_Contato);

        /* combobox  tipo tarefa*/
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.tipo_tarefa, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spi_tipo.setAdapter(adapter);
        /*------------------------------------------------------------------------------*/

        /* combobox  tipo tarefa*/
        ArrayAdapter<CharSequence> adapter_importancia = ArrayAdapter.createFromResource(this,
                R.array.importancia_tarefa, android.R.layout.simple_spinner_item);

        adapter_importancia.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spi_importancia.setAdapter(adapter_importancia);
        /*------------------------------------------------------------------------------*/

// envento selecionar combo tipo
        spi_tipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String tipoMsg = spi_tipo.getSelectedItem().toString();

//                Toast.makeText(getApplicationContext(), tipoMsg, Toast.LENGTH_SHORT).show();

                habilitaDesabilitaEditText((EditText)findViewById(R.id.txt_contato),!tipoMsg.equalsIgnoreCase("Lembrete"));





if (tipoMsg.equalsIgnoreCase("SMS")){
    //EditText txt = (EditText)findViewById(R.id.txt_contato);
    txtContato.setInputType(InputType.TYPE_CLASS_PHONE );
    label_contato.setText("Nunero do Celular");
}else if(tipoMsg.equalsIgnoreCase("Email")){
    txtContato.setInputType(InputType.TYPE_CLASS_TEXT);
    label_contato.setText("Endereço de Email");
}else{
    label_contato.setText("");
}

            }

            public void onNothingSelected(AdapterView<?> adapterView) {
                return;
            }


            private void habilitaDesabilitaEditText(EditText editText, boolean flag) {
                  editText.setEnabled(flag);

                if (flag){
                editText.setBackgroundColor(Color.WHITE);
                }else{
                    editText.setBackgroundColor(Color.TRANSPARENT);
                }
            }
        });



        bt_limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtContato.setText("");
                txtTarefa.setText("");
                txtMensagem.setText("");
                txtData.setText("");
                txtHora.setText("");
            }
        });




        bt_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  finish();
                /*  TESTE DE CONSULTA */
         /*       Tarefa tarefa = db.selecionarTarefa(Integer.parseInt(txtTarefa.getText().toString()));
                Toast.makeText(getApplicationContext(), tarefa.getMensagem(), Toast.LENGTH_SHORT).show();
                         finish();
*/
                /* TESTE DE UPDATE*/
/*                Tarefa tarefa = new Tarefa(1, "nome", 1, "contato", "UPDATE", "02/06/2017 08:00","1" );
                db.atualizaTarefa(tarefa);
                Toast.makeText(getApplicationContext(), "Atualizado com sucesso", Toast.LENGTH_SHORT).show();
*/
            }
        });



        //Botão salvar//
        bt_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String resposta="";

                if(txtTarefa.getText().toString().equalsIgnoreCase(""))
                    resposta +=  "\n *Nome da Tarefa invalida";
                if(txtMensagem.getText().toString().equalsIgnoreCase(""))
                    resposta +=  "\n *Campo Mensagem invalido";
                resposta +=  validaHora(txtHora.getText().toString());
                resposta +=  validaData(txtData.getText().toString());


                if (!spi_tipo.getSelectedItem().toString().equalsIgnoreCase("Lembrete") &&
                        txtContato.getText().toString().equalsIgnoreCase("")                ){
                    resposta +=  "\n Campo Contato é Obrigatorio";
                }




if(!resposta.equalsIgnoreCase("")){
    Toast.makeText(getApplicationContext(), resposta, Toast.LENGTH_SHORT).show();

}else{
    db.addTarefa(new Tarefa(txtTarefa.getText().toString(), spi_tipo.getSelectedItemPosition(),
            txtContato.getText().toString(), txtMensagem.getText().toString(),
            (String) (txtData.getText().toString())+ " " + txtHora.getText().toString(),
            String.valueOf(spi_tipo.getSelectedItemPosition())));

    Toast.makeText(getApplicationContext(), "Salvo com Sucesso", Toast.LENGTH_SHORT).show();
    bt_limpar.callOnClick();

}
            }
        });


        bt_contato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (spi_tipo.getSelectedItem().toString().equalsIgnoreCase("Lembrete")){
                    Toast.makeText(getApplicationContext(), "Informação não requerida para Lembrete", Toast.LENGTH_SHORT).show();
                } else {
//###########################################################################################################################
                    Uri u = Uri.parse("content://com.android.contacts/contacts");
                    Intent i = new Intent(Intent.ACTION_PICK, u);
                    startActivityForResult(i, SEL_CONT);
//###########################################################################################################################
                }
            }
        });

    }

    public String validaHora( String hora){
        try{
            if(hora.replace(":","").length() != 4 || !isNumber(hora.replace(":","")) ||
                Integer.parseInt(hora.substring(0,2)) > 23  || Integer.parseInt(hora.substring(0,2)) < 0 ||
                Integer.parseInt(hora.substring(3,5)) > 59  || Integer.parseInt(hora.substring(0,2)) < 0
                ){
            return "\n *Hora Invalida";
                }
        return "";
            } catch (Exception E) {
    return  "";
}


}


    public String validaData( String data){

      if(data.length() != 10 || !isDate(data.toString())){
            return "\n *Data Invalida";
                  }
        return "";
    }

public boolean isNumber( String entrada){

    try
    {
        Integer.parseInt(entrada);
        return  true;
    } catch (Exception E) {
        return  false;
    }


}


    public boolean isDate( String entrada){
int dia, mes, ano;

        try
        {
            dia = Integer.parseInt(entrada.substring(0,2));
            mes = Integer.parseInt(entrada.substring(3,5));
            ano = Integer.parseInt(entrada.substring(6,10));

            if(dia < 1 || dia > 31)
                return false;
            if(mes < 1 || mes > 12)
                return false;
            if(ano < 12 || ano > 9999)
                return false;
            return  true;
        } catch (Exception e ) {
            return  false;
        }


    }

    protected void onActivityResult(int requestCode, int ResultCode, Intent i){
try {
    Uri u = i.getData();
    Cursor c = getContentResolver().query(u, null, null, null, null);
    c.moveToNext();

    String hasPhone = c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
    String id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));

        /* Envia o nome do contato para o editText*/
    String name = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
    txtMensagem.setText(
            txtMensagem.getText() + " - " +
            name, TextView.BufferType.EDITABLE);


    if (spi_tipo.getSelectedItem().toString().equalsIgnoreCase("SMS")) {


        /*Encontra o numero do contato e envia para o editText*/
        if (hasPhone.equalsIgnoreCase("1")) {
            Cursor cPhone = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + id, null, null);

            cPhone.moveToNext();

            String number = cPhone.getString(cPhone.getColumnIndex("data1"));
            txtContato.setText(number
                    , TextView.BufferType.EDITABLE);
        } else {
            Toast.makeText(this, "No Phone Number Found", Toast.LENGTH_SHORT).show();
            txtContato.setText(" ", TextView.BufferType.EDITABLE);
        }
    } else {
        /*Encontra o email do contato e envia para o editText*/


        try {
            Cursor cEmail = getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = " + id, null, null);

            cEmail.moveToNext();

            String email = cEmail.getString(cEmail.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS));
            txtContato.setText(email
                    , TextView.BufferType.EDITABLE);

        } catch (Exception e) {

            Toast.makeText(this, "No email found", Toast.LENGTH_SHORT).show();
            txtContato.setText(" ", TextView.BufferType.EDITABLE);

        }

    }
}catch (Exception E){

    txtContato.setText(" ", TextView.BufferType.EDITABLE);
}
    }


}
